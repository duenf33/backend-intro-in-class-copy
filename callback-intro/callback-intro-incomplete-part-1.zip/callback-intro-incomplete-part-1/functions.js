const identity = function (value) {};
const first = function (array, n) {};

const last = function (array, n) {};
const each = function (collection, iterator) {};
const indexOf = function (array, target) {};
const map = function (collection, iterator) {};

module.exports = {
  identity,
  first,
  last,
  each,
  indexOf,
  map,
};
